package other.SocketService;

public class MessageToSocket {
    public MessageToSocket() {}


}
