//import java.util.Collections;
//
//public interface BD {
//d
//    public int addUser(String pseudo, String mdp, String mail);
//    public int deleteUser(User user);
//    public
//}
