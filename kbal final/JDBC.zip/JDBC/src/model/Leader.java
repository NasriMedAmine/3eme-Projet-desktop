package model;

public class Leader extends User {

}
