import java.sql.SQLException;
import java.util.Scanner;

public class MainAdmin {
    static Scanner myScanner1 = new Scanner(System.in);

    public static void main(String[] args) throws ClassNotFoundException, SQLException{


    }
}
