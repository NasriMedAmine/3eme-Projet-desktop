if (self.CavalryLogger) { CavalryLogger.start_js_script(document.currentScript); }

__d("LSUpsertGradientColor",[],(function(a,b,c,d,e,f){function a(){var a=arguments,b=a[a.length-1];b.n;var c=[];return b.seq([function(c){return b.db.table(117).put({themeFbid:a[0],gradientIndex:a[1],color:a[2],type_:[0,0]})},function(a){return b.resolve(c)}])}e.exports=a}),null);