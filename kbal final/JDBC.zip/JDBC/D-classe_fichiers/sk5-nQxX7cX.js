if (self.CavalryLogger) { CavalryLogger.start_js_script(document.currentScript); }

__d("LSDeleteThenInsertMessageRequest",[],(function(a,b,c,d,e,f){function a(){var a=arguments,b=a[a.length-1];b.n;var c=[];return b.seq([function(c){return b.db.table(34).put({threadKey:a[0],messageRequestStatus:a[2]})},function(a){return b.resolve(c)}])}e.exports=a}),null);