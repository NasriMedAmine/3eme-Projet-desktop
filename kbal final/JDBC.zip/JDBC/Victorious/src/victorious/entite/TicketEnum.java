package victorious.entite;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jasse
 */
public enum TicketEnum {
    Reclamation, feedback, dem_validation;
}
